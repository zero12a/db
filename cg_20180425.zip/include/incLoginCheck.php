<?
//로그인 검사
if(!isLogin())MsgExit("Check login");
?>