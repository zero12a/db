<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <title>Document</title>
 </head>
 <body>
  <form method="post" action="cg_login_ok.php">
	<input type="password" name="pw" value="">
	<input type="submit" value="go">
  </form>
 </body>
</html>
