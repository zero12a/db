<?php
//DAO
 
class layout4iDao
{
	function __construct(){
		alog("Layout4iDao-__construct");
	}
	function __destruct(){
		alog("Layout4iDao-__destruct");
	}
	function __toString(){
		alog("Layout4iDao-__toString");
	}
}
                                                             
?>