<?php
//DAO
 
class layout4hDao
{
	function __construct(){
		alog("Layout4hDao-__construct");
	}
	function __destruct(){
		alog("Layout4hDao-__destruct");
	}
	function __toString(){
		alog("Layout4hDao-__toString");
	}
}
                                                             
?>